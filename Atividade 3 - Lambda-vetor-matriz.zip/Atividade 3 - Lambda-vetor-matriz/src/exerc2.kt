//exercício de lambda
package lambdas
//função adicionada para realizar a soma das variáveis
fun soma(a:Int, b:Int): Int {
    return a + b
}
fun main(args: Array<String>) {
     println("Digite o primeiro numero: ")
    val X:Int = readLine()!!.toInt()
    //NullPointerException
    print("Digite o segundo numero: ")
    val Y:Int = readLine()!!.toInt()

    val resultado:Int = soma(X, Y)
    println("O resultado da soma é = $resultado")
}
// Metodo para somar dois numeros.